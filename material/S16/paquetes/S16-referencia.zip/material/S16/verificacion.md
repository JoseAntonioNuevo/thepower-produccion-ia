# Verificación de la base común y S16

## Actualización docente del 06/11/2026

Alcance: misma versión para el 12/11 M/J y el 18/11 L/X. Cambios en presentación, notas, QR, guion, guía, enunciado, cobertura, checklist y paquetes. La práctica se presenta como opcional. El guion ampliado de Word también se actualizó en la carpeta general y se incorporó al paquete de S16.

- Presentación final: **24 diapositivas y 24 notas del orador**. Integridad, geometría, Arial/Courier New, tablas editables, sumas e importación con Artifact Tool correctas. PDF: **24 páginas**, revisadas visualmente. SHA-256 PPTX: `9fc24902425bce04c7faa9fc69e5d4879124aa5768b49b9cb61d89ab9f0b60ae`.
- QR: bytes exactos del adjunto de Laura del 19/10; SHA-256 `29c9041e732152679956162fe522a0433d70ad633145990f14327853fddde8c6`. Se decodificó también desde el PDF renderizado: formulario AI Engineer en `kb.tools.thepower.education`.
- Recorrido: seis pasos con acción, comprobación esperada y preguntas; lectura explícita en consola de ECR, definición de tarea, red y CloudWatch. IA gestionada forma parte del bloque principal.
- Guion PDF: **7 páginas**; guía PDF: **6 páginas**, renderizadas y revisadas. Word ampliado: **13 páginas**; cronograma de 90 minutos y referencias ajustados a las 24 diapositivas.
- Costes reproducidos: **13,78 USD/730 horas**; **0,46 USD con 90 minutos de cómputo/IP y 30 días de ECR, secreto y logs almacenados**. Desglose visible de 0,0260 / 0,4253 / 0,0058 USD; total calculado antes de redondear. Inferencia aparte. No son importes facturados.
- Checks del repositorio: Ruff lint y formato correctos, **45 tests**, `cfn-lint` de S16/S17 y preflight offline correctos. Se conserva la advertencia conocida de TestClient/httpx.
- Distribución: inicio **20 archivos**, referencia **53 archivos**, con listas de inclusión de S16. Se excluyen módulos serverless/S17, secretos, entornos y evidencias operativas. Los ZIP se extrajeron en carpetas limpias: instalación con lock, **16 tests del inicio** y **24 de referencia**, preflight demo y `cfn-lint` S16 correctos. Las revisiones finales de documentos no alteran código ni lock comprobados.
- El ensayo AWS real, la inferencia real, la limpieza remota y el ensayo oral siguen pendientes. No se han creado recursos ni hecho llamadas de pago en esta actualización.
- OpenViking: el selector `/Users/jose/.config/openviking/workspace-account.sh` para este repositorio devolvió código 1; no hay cuenta verificada. Registro local; memoria externa pendiente. Sin commit, push, envío a Laura ni publicación en plataforma.

## Preparación original del 17/10/2026

El registro siguiente corresponde a la versión inicial de 20 diapositivas; sus hashes, números de páginas y conteos de pruebas son históricos. Para la versión vigente se utiliza la actualización anterior.

Fecha: 17/10/2026. Alcance: código local, contenedor y materiales docentes. No se ha creado ningún recurso AWS, no se ha publicado una imagen en ECR y no se han hecho llamadas reales a Anthropic desde este proyecto.

## Cobertura docente

- Matriz con **26 puntos de cobertura** del temario/ejercicio y una ampliación opcional.
- Cada requisito tiene diapositivas y bloque del guion identificados.
- Guion con ocho bloques continuos de 18:30 a 20:00: **90 minutos**.
- S17–S20 conservan su inventario en `docs/cobertura-S16-S20.md`; todavía no son entregas implementadas.

## Código y plantillas

| Comprobación | Resultado |
|---|---|
| Instalación Python 3.12 con lock | Correcta; dependencias directas fijadas y resolución completa conservada |
| Ruff lint y formato | Correctos |
| Pytest del proyecto | **24 pruebas correctas** |
| CloudFormation registro y servicio | `cfn-lint` correcto, sin hallazgos |
| Preflight | Demo; sin clave/configuración real, sin comprobaciones remotas |
| CLI AWS sin `--execute` | Plan offline, sin inicializar una sesión operativa |
| Guardas | Recibo de otra cuenta/región/imagen rechazado; stack ajeno rechazado; cuenta STS errónea detenida; secreto compartido no borrado |

Los tests del adaptador usan `httpx.MockTransport`: acreditan formato, errores, tiempo/límites y ausencia de reintentos/redirecciones, no disponibilidad de un modelo real. Starlette emite una advertencia de deprecación de su compatibilidad de TestClient con httpx; la suite termina correctamente. El adaptador HTTP de la aplicación utiliza httpx de forma explícita.

## Contenedor y HTTP

- Build real `linux/amd64` correcto sobre la base Python fijada por digest.
- Contenedor ejecutado con usuario **10001:10001**, raíz de solo lectura, sin capabilities y `no-new-privileges`.
- Healthcheck del contenedor observado como `healthy`.
- GET `/health` correcto; POST sintético devuelve categoría `facturacion` y `execution: demo`.
- Entrada vacía devuelve 422; cuerpo excesivo devuelve 413.
- Ensayo repetido tras limitar el contenedor a **0,25 CPU y 512 MiB**, coherente con la tarea prevista. La instantánea local observó 57,6 MiB de memoria; no es una medición de producción ni una garantía de dimensionamiento.
- Recibos en `evidencias/local/`, fuera de Git y de los paquetes públicos.

## Presentación y documentos

- PPTX con **20 diapositivas y 20 notas del orador**, texto y tablas editables.
- Validaciones de integridad, geometría, fuentes, tablas nativas, suma de costes e importación correctas.
- SHA-256 del PPTX validado: `bc2c114d6b5d33165ecabe63d917d279a5a3876d024540aee36d9425892ea241`.
- Las 20 diapositivas se renderizaron y revisaron; se ajustó la separación de los encabezados de servicios de IA.
- PDF de presentación: 20 páginas, exportado desde el PPTX con LibreOffice. Todo el texto de las diapositivas aparece en el PDF; no se encontraron caracteres fuera del lienzo. El PDF embebe Liberation Sans/Mono, mientras el PPTX declara Arial/Courier New; la composición se revisó visualmente.
- QR original de AI Engineer incorporado con los mismos bytes que el archivo de referencia.
- Guion: 6 páginas PDF. Guía del alumno: 5 páginas PDF. Todas sus páginas se renderizaron y revisaron; los comandos tienen tipografía monoespaciada legible y se evitaron encabezados aislados al final de página.

## Costes y distribución

- Tarifas públicas de nueve partidas leídas para `eu-west-1`; SKU, unidad, publicación, efectividad y URL en `docs/fuentes/tarifas-aws-2026-10-17.json`.
- Calculadora ejecutada: **13,78 USD/730 horas** y **0,46 USD/demo de 90 minutos con ECR y secreto conservados un mes**, sin inferencia. Son estimaciones con cantidades supuestas, no consumo de una cuenta.
- Paquete de inicio extraído en carpeta limpia: instalación desde lock y **16 pruebas correctas**.
- Paquete de referencia extraído en carpeta limpia: instalación desde lock y **24 pruebas correctas**. Las revisiones finales de presentación y documentación no cambian esos archivos de código/lock.
- Los ZIP excluyen entornos, caches, claves y evidencia operativa. Sus hashes se generan en `paquetes/manifiesto.json`.

## Pendiente para el ensayo real de la clase

1. Identificar cuenta, región, perfil, permisos, presupuesto y modelo disponible del laboratorio.
2. Publicar la imagen, crear/seleccionar el secreto y desplegar las plantillas con autorización de esa operación.
3. Verificar digest/task definition, salud e inferencia real; guardar recibo y respaldo fechado.
4. Ensayar retirada e inventario de recursos y secretos, distinguiendo borrado programado y recursos compartidos.
5. Completar ensayo oral de José, reunión, pantalla y grabación.

La preparación local y la cobertura documental están verificadas. La ejecución AWS, la inferencia real y la aceptación oral del profesor no se declaran completadas. Repositorio local iniciado sin commit, push ni remoto. OpenViking pendiente por falta de cuenta mapeada.

