# S16 Cloud deployment con AWS y Docker

**Versión común: 12 de noviembre (M/J) y 18 de noviembre (L/X) de 2026 · 18:30–20:00 Europe/Madrid.** El QR actualizado el 19/10 evalúa S15, la sesión anterior de cada grupo. La práctica es opcional.

1. [Presentación editable](presentaciones/S16-cloud-docker.pptx) y [PDF](presentaciones/S16-cloud-docker.pdf).
2. [Guion del profesor](guion-profesor.md), [PDF](guion-profesor.pdf) y [guion ampliado en Word](guion-profesor.docx).
3. [Guía del alumno](guia-alumno.md) y [versión PDF](guia-alumno.pdf).
4. [Cobertura de requisitos](cobertura.md) y [evidencia de verificación](verificacion.md).
5. [Enunciado y entrega](enunciado.md), [fuentes](fuentes.md) y [lista antes del directo](checklist.md).
6. [Punto de partida del alumno](paquetes/S16-inicio.zip) y [proyecto de referencia completo](paquetes/S16-referencia.zip), con [manifiesto de hashes](paquetes/manifiesto.json).

Las diapositivas 1–22 se intercalan con código, terminal y consola. Las 23–24 son de consulta. La 3 presenta el recorrido; las 10, 12, 14–16 y 21 guían los seis pasos. La 6 incorpora IA gestionada al bloque principal. Las 19–20 hacen explícitos los supuestos del coste. Las notas del orador explican cada diapositiva y remiten al guion. El punto de entrada es `S16-inicio.zip`, con la API ya preparada. La solución completa queda como consulta; en directo se muestran los archivos y recursos de S16 por pasos.

La simulación local permite practicar sin gasto. Para mostrar una integración real hay que ejecutar una llamada real, conservar el resultado y rotular cualquier reproducción anterior. Antes del directo queda el ensayo específico con cuenta, permisos y presupuesto AWS del laboratorio.

