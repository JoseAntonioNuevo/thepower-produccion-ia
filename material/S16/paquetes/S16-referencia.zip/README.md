# Referencia S16

Versión común para el 12 y 18 de noviembre de 2026. La práctica es opcional.
Empieza por material/S16/README.md y sigue material/S16/guia-alumno.md.
Este ZIP contiene la API, Docker, scripts, plantillas AWS y materiales de S16.
Para practicar desde una API preparada, usa S16-inicio.zip y la guía entregada.
Los comandos AWS de creación, publicación, inferencia y retirada generan operaciones
reales; ejecuta solo dentro de la cuenta y presupuesto autorizados del laboratorio.
