# Punto de partida S16

Versión común para el 12 y 18 de noviembre de 2026. Práctica opcional.
Incluye la API y sus tests. Si decides hacerla, construirás Docker y desplegarás en AWS.
También protegerás secretos y prepararás evidencias, coste y limpieza conforme al enunciado.
Sigue la guía paso a paso entregada junto a este ZIP. El paquete S16-referencia
contiene la solución docente para consultar cada paso sin recorrer otras sesiones.

Desde esta carpeta:
    uv sync --frozen --all-extras
    uv run pytest
    uv run python scripts/preflight.py
    uv run uvicorn curso_ia.api:create_app --factory --host 127.0.0.1 --port 8016

En otra terminal:
    uv run python scripts/ensayo_local.py

El modo inicial es demo y no consume modelos. No incluye un Dockerfile resuelto.
