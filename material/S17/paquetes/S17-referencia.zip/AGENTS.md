# thePower Producción de IA

Repositorio independiente del curso AI Engineer. Alcance implementado:
base Python, S16 (FastAPI/Docker/Fargate) y S17 (Lambda/HTTP API IAM/Bedrock),
con código y paquetes docentes. S18–S20 están planificadas.

## Contratos

- Python 3.12, instalación con `uv sync --frozen --all-extras` y `uv.lock`.
- `API_MODE=demo` es una simulación rotulada; `real` usa Anthropic Messages.
  Un error real nunca activa una simulación ni cambia de proveedor.
- `GET /health` comprueba el proceso; `POST /clasificar` valida entrada y salida.
- S17 reutiliza el contrato en un handler Lambda y usa IAM para Bedrock. El
  handler local de RIE es una demo explícita; la plantilla despliega el real.
- La firma usa credenciales temporales; no guardar headers Authorization.
- Sin datos personales, secretos en Git ni claves dentro de imágenes o materiales.
- Las categorías y prioridades proceden de S7/S8. El nuevo módulo es independiente
  y no requiere acceder a los otros repositorios ni a rutas de este Mac.
- Comentarios y guías en español: explicar finalidad, límites y pasos no triviales.
- No ampliar a RAG, Lambda, MCP o base de datos hasta trabajar su sesión.
- `CLAUDE.md` es un enlace relativo a este archivo.

## Verificación

`uv run ruff check .`, `uv run ruff format --check .`, `uv run pytest`,
`uv run cfn-lint infra/s16/*.json infra/s17/*.json` y el preflight offline.
`scripts/ensayo_local.py` prueba una API de demostración en loopback y guarda un recibo.
La validación de Docker y de AWS es independiente de los tests Python.
No afirmar despliegue, coste real ni inferencia real a partir del modo demo.

## AWS

Los comandos de modificación de `scripts/aws_lab.py` requieren `--execute`, perfil,
región, cuenta esperada y nombre propio del laboratorio. Es una barrera del CLI,
no autorización para que un agente despliegue. Crear recursos, gastar o borrarlos
requiere que José haya autorizado esa operación y destino.
Las plantillas usan IP pública temporal y entrada restringida a una IPv4 /32.
La limpieza conserva los secretos externos y otros recursos compartidos.
S17 se opera con `uv run python -m scripts.aws_s17`: preflight/estado/logs son
lecturas; mutaciones e inferencias exigen `--execute`. El lote tiene seis
intentos como máximo y no reintenta fallos. Regiones, perfil y cuotas se leen
antes del deploy; no hay fallback a un perfil global.

## Memoria y entrega

El selector OpenViking no tiene una cuenta mapeada para este nuevo repositorio.
Conservar decisiones y evidencia local; no atribuir el proyecto a otro tenant.
El contexto completo está en `docs/` y la cobertura docente en `material/S16/`
y `material/S17/`. S17 también tiene un lock de runtime Lambda independiente.
Hacer el trabajo en el agente actual salvo petición explícita de delegación.
Commit, publicación y despliegue son etapas separadas que José debe solicitar.

