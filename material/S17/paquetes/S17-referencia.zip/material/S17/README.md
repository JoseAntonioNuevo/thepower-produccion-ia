# S17 Serverless AI con Bedrock y Lambda

**AI Engineer · M/J: 17/11/2026 · L/X: 23/11/2026 · 18:30–20:00 Europe/Madrid.**

La sesión conserva el contrato de soporte de S16 y cambia el recorrido a HTTP API con IAM, Lambda y Bedrock. Cada grupo puede utilizar este paquete sin tener el repositorio de otro profesor.

1. [Presentación editable](presentaciones/S17-serverless-ai.pptx) y [PDF](presentaciones/S17-serverless-ai.pdf), con notas para ambas promociones.
2. [Guion completo del profesor](guion-profesor.md) y [PDF](guion-profesor.pdf).
3. [Guía del alumno](guia-alumno.md) y [PDF](guia-alumno.pdf).
4. [Enunciado](enunciado.md), [cobertura](cobertura.md), [verificación](verificacion.md) y [checklist](checklist.md).
5. [Fuentes](fuentes.md), [paquete de inicio](paquetes/S17-inicio.zip) y [referencia completa](paquetes/S17-referencia.zip).
6. [ZIP Lambda compilado](paquetes/lambda-s17.zip) y [manifiesto del runtime](paquetes/lambda-manifiesto.json). Está construido para Linux amd64; no está desplegado.

El QR de AI Engineer evalúa **S16 del 12/11 en M/J** o **S16 del 18/11 en L/X**. La fecha del grupo se anuncia al comenzar. La presentación se intercalará con código, terminal y evidencias; los anexos amplían permisos y comandos.

La demo y el emulador local no consumen modelos y se identifican como tales. La firma sin conexión no acredita que IAM autorice una llamada. Antes del directo se debe completar un ensayo AWS con la cuenta, permisos y presupuesto del laboratorio, conservar resultados reales y comprobar su retirada.

