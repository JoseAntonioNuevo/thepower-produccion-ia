# S16 Cloud deployment con AWS y Docker

**12 de noviembre de 2026 · AI Engineer M/J · 18:30–20:00 Europe/Madrid.** El QR evalúa S15, del 10 de noviembre.

1. [Presentación editable](presentaciones/S16-cloud-docker.pptx) y [PDF](presentaciones/S16-cloud-docker.pdf).
2. [Guion completo del profesor](guion-profesor.md) y [versión PDF](guion-profesor.pdf).
3. [Guía del alumno](guia-alumno.md) y [versión PDF](guia-alumno.pdf).
4. [Cobertura de requisitos](cobertura.md) y [evidencia de verificación](verificacion.md).
5. [Enunciado y entrega](enunciado.md), [fuentes](fuentes.md) y [lista antes del directo](checklist.md).
6. [Punto de partida del alumno](paquetes/S16-inicio.zip) y [proyecto de referencia completo](paquetes/S16-referencia.zip), con [manifiesto de hashes](paquetes/manifiesto.json).

Las diapositivas 1–17 se intercalan con código, terminal y consola. Las 18–20 son de consulta. Las notas del orador explican cada diapositiva y remiten al guion. La clase utiliza el proyecto completo; el alumno puede comenzar con el paquete `S16-inicio.zip` y construir Docker/AWS siguiendo la guía.

La simulación local permite practicar sin gasto. Para mostrar una integración real hay que ejecutar una llamada real, conservar el resultado y rotular cualquier reproducción anterior. Antes del directo queda el ensayo específico con cuenta, permisos y presupuesto AWS del laboratorio.

