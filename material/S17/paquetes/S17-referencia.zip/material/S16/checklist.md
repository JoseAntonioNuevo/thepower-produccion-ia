# Lista antes del directo S16

- [ ] Reunión correcta, cuenta de AI Engineer, grabación automática activa y pantalla sin secretos.
- [ ] QR de AI Engineer visible; evalúa S15 del 10/11.
- [ ] Presentación/PDF y guion canónicos abiertos; terminal con texto legible.
- [ ] Instalación desde lock y tests locales correctos en la versión que se enseñará.
- [ ] Contenedor ensayado, usuario 10001 y arquitectura coherente con Fargate.
- [ ] Perfil, cuenta, región, permisos, presupuesto y nombre de laboratorio confirmados.
- [ ] IP pública del profesor y /32 de entrada comprobados, incluida VPN.
- [ ] Modelo y secreto disponibles; una inferencia real ensayada dentro del presupuesto.
- [ ] Imagen anterior identificada y recibos de deploy/salud/función preparados.
- [ ] Tarifas/fecha revisadas y supuestos visibles; inferencia separada.
- [ ] Procedimiento de limpieza ensayado y propiedad de secretos documentada.
- [ ] Respaldo local, casos de error y corte de espera a las 19:12 preparados.
- [ ] Ensayo oral completo de 90 minutos, incluyendo preguntas y limpieza.

Después: verificar recursos residuales, guardar evidencias sin secretos y registrar cualquier pendiente antes de dar la práctica por cerrada.

