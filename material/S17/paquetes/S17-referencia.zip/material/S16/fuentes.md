# Fuentes de S16

Revisión de preparación: 17/10/2026.

- Temario original de AI Engineer del 17/07: copia en `docs/fuentes/temario-ai-engineer.txt`.
- Ejercicio de S16 redactado por José, enviado el 28/09/2026: `AI_Engineer_enunciados.docx`, página 5, [correo original](https://mail.google.com/mail/u/0/#all/1a0e699466bafc2e). La guía desarrolla esos requisitos; no atribuye sus elecciones concretas a Laura.
- [AWS CloudFormation TaskDefinition](https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-ecs-taskdefinition.html): plantilla y propiedades.
- [Execution role de ECS](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/task_execution_IAM_role.html): arranque, imagen, logs y secretos.
- [Red de Fargate](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/fargate-task-networking.html): ENI, subred, IP y acceso de red.
- [Servicios AWS y Azure](https://learn.microsoft.com/en-us/azure/architecture/aws-professional/services): correspondencias funcionales, no equivalencia exacta.
- [Fargate Pricing](https://aws.amazon.com/fargate/pricing/) y catálogo AWS Price List: tarifas seleccionadas, SKU, unidad, fecha y URL en `docs/fuentes/tarifas-aws-2026-10-17.json`.
- [FastAPI lifespan](https://fastapi.tiangolo.com/advanced/events/) y [pruebas de lifespan](https://fastapi.tiangolo.com/advanced/testing-events/): administración y prueba del cliente compartido.
- [Anthropic Python SDK y tipos de Messages](https://github.com/anthropics/anthropic-sdk-python): cuerpo de petición, respuesta, stop reason y consumo; la implementación del curso usa HTTP acotado.

Logo: recurso thePower ya utilizado en S5/S6. QR: archivo original de AI Engineer recibido con la confirmación de ejercicios del 29/09 y reutilizado sin modificación. Los recursos no se han recreado ni se han sustituido por un QR inventado.
