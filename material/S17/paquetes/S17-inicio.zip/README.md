# Punto de partida S17

Contiene la API y contratos de soporte para alumnos que no tienen nuestra S16.
El trabajo autónomo es construir Lambda, Bedrock, la HTTP API IAM, firma, medidas,
costes y retirada según el enunciado. El paquete S17-referencia contiene la solución
y la guía completa; sus comandos AWS requieren esa versión resuelta.

Desde esta carpeta:
    uv sync --frozen --all-extras
    uv run pytest
    uv run python scripts/preflight.py
    uv run uvicorn curso_ia.api:create_app --factory --host 127.0.0.1 --port 8016

En otra terminal:
    uv run python scripts/ensayo_local.py

Es una demostración local, sin AWS ni modelos de pago.
